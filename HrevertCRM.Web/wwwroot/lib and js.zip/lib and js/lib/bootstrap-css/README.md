# Bootstrap


This is a Bower component for [Bootstrap 3](http://getbootstrap.com/) CSS library (v3.3.6).

## Installation:

`bower install bootstrap-css`

## Bootstrap 3.0 versions

```
bower install bootstrap-css#3.3.6
bower install bootstrap-css#3.3.5
bower install bootstrap-css#3.3.4
bower install bootstrap-css#3.3.2
bower install bootstrap-css#3.2.0
bower install bootstrap-css#3.1.1
bower install bootstrap-css#3.1.0
bower install bootstrap-css#3.0.0
```


## Bootstrap 2.3 versions

```
bower install bootstrap-css#2.3.2
bower install bootstrap-css#2.3.1
bower install bootstrap-css#2.3.0
```
