/**
 * A couple of examples to show case what can be done with the MagicSuggest component
 */
$(function() {
    $('#ms-scrabble').magicSuggest({
        placeholder: 'Type some real or fake fruits',
        data: ['Banana', 'Apple', 'Orange', 'Lemon']
    });
});