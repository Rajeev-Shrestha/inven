﻿(function () {
    angular.module("app-pricingrule")
        .controller("pricingruleController", pricingruleController);
    function pricingruleController() {
        
    }


})();